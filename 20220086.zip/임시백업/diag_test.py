import flet as ft
import traceback

def main(page: ft.Page):
    page.title = "다이얼로그 진단 테스트"
    log_text = ft.Text("로그: 아직 클릭 안 함", size=14)

    def close_dialog(e):
        print(">>> close_dialog 호출됨")
        page.pop_dialog()

    def on_click(e):
        print(">>> 버튼 클릭됨, on_click 진입")
        log_text.value = "버튼 클릭됨"
        page.update()
        try:
            dlg = ft.AlertDialog(
                title=ft.Text("테스트 다이얼로그"),
                content=ft.Text("이게 보이면 성공입니다"),
                actions=[ft.TextButton("닫기", on_click=close_dialog)],
            )
            print(">>> show_dialog 호출 직전")
            page.show_dialog(dlg)
            print(">>> show_dialog 호출 완료 (에러 없음)")
            log_text.value = "show_dialog 호출 완료"
            page.update()
        except Exception as err:
            print(">>> 에러 발생:", err)
            traceback.print_exc()
            log_text.value = f"에러: {err}"
            page.update()

    page.add(
        ft.ElevatedButton("다이얼로그 테스트", on_click=on_click),
        log_text,
    )

if __name__ == "__main__":
    ft.run(main)